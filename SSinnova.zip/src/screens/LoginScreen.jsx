import { Alert, Text, View, StyleSheet, TextInput, Button, Pressable } from "react-native";
import { SafeAreaView } from 'react-native-safe-area-context'
import Ionicons from "@react-native-vector-icons/ionicons/static";
import { formularioStyles } from '../styles/formularioStyles'
import {useState} from 'react'
function LoginScreen({navigate}) {
 const [email, setEmail] = useState('');
 const [senha, setSenha] = useState('');

function login(){
    console.log('Fazer login!');
    Alert.alert('Login','Fazer login');
}


    return (
        <SafeAreaView style={styles.container}>
            <Ionicons name="person-circle" size={100} color="#1A418E" />
            <Text style={styles.textoLogin}>Login</Text>
            <Text nativeID="email" style={[formularioStyles.label, styles.textoLabel]}>Email:</Text>
            <TextInput accessibilityLabelledBy="email" placeholderTextColor='#ff2525' value={email} onChangeText={setEmail} style={formularioStyles.input} placeholder="Digite seu melhor email" />
            <Text nativeID="senha" style={[formularioStyles.label, styles.textoLabel]}>Senha:</Text>
            <TextInput accessibilityLabelledBy="senha"  value={senha} onChangeText={setSenha} style={formularioStyles.input} placeholder="Digite sua senha" />
            <Text style={styles.textoEsqueceuSenha}>Esqueceu sua senha?</Text>
            <Pressable onPress={login} style={({pressed}) => [formularioStyles.botaoLogin, {opacity : pressed ? 0.85 : 1 }]}>
                <Text >Entrar</Text>
            </Pressable>
            <Text style={styles.textoNaoConta}>Não tem conta? <Text style={styles.textoCadastrese}>Cadastre-se</Text></Text>
        </SafeAreaView>
    );
}
export default LoginScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        marginHorizontal: 20,
    },
    textoEsqueceuSenha: {
        alignSelf: 'flex-end',
        marginTop: 10,
        marginBottom: 10,
        color: '#1A418E'
    },
    textoLogin: {
        fontSize: 32,
        fontWeight: 'semibold',
        color: '#1A418E',
    },
    textoLabel: {
        marginBottom: 5,
        marginTop: 10,
    },
    textoNaoConta: {
        marginTop: 50,
        color: '#1A418E',
    },
    textoCadastrese: {
        fontWeight: 'bold',

    },
    botao: {
        marginTop: 10,
    }
});
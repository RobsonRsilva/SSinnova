import LoginScreen from './src/screens/LoginScreen';
import HomeScreen from './src/screens/HomeScreen';
import CadastroScreen from './src/screens/CadastroScreen';
import { SafeAreaProvider } from 'react-native-safe-area-context'
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { NavigationContainer } from '@react-navigation/native';
function App() {
  const Stack = createNativeStackNavigator();
  return (
    <SafeAreaProvider>
      <NavigationContainer>
        <Stack.Navigator>
          <Stack.Screen name='Home' component={<HomeScreen />} />
          <Stack.Screen name='Login' component={<LoginScreen />} />
          <Stack.Screen name='Cadastro' component={<CadastroScreen />} />
        </Stack.Navigator>
      </NavigationContainer>

    </SafeAreaProvider>

  );
}
export default App;